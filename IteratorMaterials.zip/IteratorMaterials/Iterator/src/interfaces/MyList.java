package interfaces;

/*
NOTE: The Iterator interface allows you to use an enhanced for loop
(sometimes called the foreach loop) on any class that implements
the interface.  Iterator is typically attached to classes that contain
some form of collection of data (array, ArrayList, etc.) as one of 
its primary fields.

The Iterator is used to keep track of the current location in a collection
and move through the collection one step at a time.

*/
import java.util.*;

public class MyList implements Iterable<String>
{
	private ArrayList<String> list;
	
	public MyList()
	{
	   this.list = new ArrayList<String>();
	
	}//end default constructor
	
	public void addLast(String str)
	{
	   this.list.add(str);
	}//end addLast
	
	public int size()
	{
	   return this.list.size();
	
	}//end size method
	
	public String toString()
	{
	   String result = "";
	   
	   for (Object o: this)
	      result += o + "\r\n";
	      
	   return result;
	
	}//end toString
	
	public Iterator<String> iterator()
	{
	   return new MyListIterator(0, this.list);
	}//end iterator -- required by Iterable interface
	
	
	
	/* Nested class to provide a means of iterating across the MyList collection.
	 * Implement the Iterator interface and provide the methods (hasNext and next) required by that
	 * interface based on discussion from the Java API documentation.
	 * 
	 * An iterator is a class that encapsulates how to traverse the items in a class
	 * that contains an aggregate or collection of items.  The MyList class is such a class.
	 * It contains an ArrayList of Strings.
	 * 
	 * Through the use of the hasNext and next methods of the Iterator interface, 
	 * the MyListIterator class below should provide a means to walk through the ArrayList
	 * in MyList.
	 * 
	 * The reason an Iterator is so important is that it lets you use the enhanced for loop
	 * provided by Java to easily traverse a collection/aggregate class.  The tester files
	 * show usage of the enhanced for loop as well as working with the Iterator directly.
	 * Look at the test examples carefully to help you properly implement the hasNext and
	 * next methods.
	 * 
	 * Finally note that the type of data you will iterate across is String.  This means you will need
	 * to specify <String> as your iterator type.  As a result, your next method will also need to return
	 * type String.
	 */
	public class MyListIterator implements Iterator<String>
	{  
	   private int cur;
	   private ArrayList<String> listRef;
	   
	   public MyListIterator(int start, ArrayList<String> list)
	   {
	      this.cur = start;
	      this.listRef = list;
	   
	   }
	   
	   @Override
	   public boolean hasNext()
	   {
	      return this.cur < listRef.size();
	   }//end hasNext
	   
	   @Override
	   public String next()
	   {
	      if (hasNext())
	      {
	         String data = listRef.get(this.cur);
	         this.cur++;
	         return data;
	      
	      }
	      throw new IllegalStateException("next method called with no items left in iteration");
	   
	   }//end next
	   
	   public void remove()
	   {
	      throw new UnsupportedOperationException("remove not implemented for MyListIterator");
	   }
	
	}//end nested class MyListIterator


}//end class MyList