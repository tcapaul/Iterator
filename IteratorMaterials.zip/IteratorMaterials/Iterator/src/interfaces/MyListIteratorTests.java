package interfaces;

import static org.junit.Assert.*;

import java.util.Iterator;

import org.junit.Test;

public class MyListIteratorTests {

	@Test
	public void testIteratorOnEmptyMyList() {
		try{
			MyList list = new MyList();
			String actual = "";
			String expected = "";
			
			for (String s: list)
				actual += s + "\r\n";
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testIteratorOnEmptyMyList: " + e.getMessage());
		}
		
	}
	
	@Test
	public void testManualIteratorOnEmptyMyList() {
		try{
			MyList list = new MyList();
			String actual = "";
			String expected = "";
			
			Iterator<String> it = list.iterator();
			while(it.hasNext())
				actual += it.next() + "\r\n";
			
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testManualIteratorOnEmptyMyList: " + e.getMessage());
		}
		
	}
	
	@Test
	public void testIteratorOnOneItemMyList() {
		try{
			MyList list = new MyList();
			list.addLast("one");
			String actual = "";
			String expected = "one\r\n";
			
			for (String s: list)
				actual += s + "\r\n";
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testIteratorOnOneItemMyList: " + e.getMessage());
		}
		
	}
	
	@Test
	public void testManualIteratorOnOneItemMyList() {
		try{
			MyList list = new MyList();
			list.addLast("one");
			String actual = "";
			String expected = "one\r\n";
			
			Iterator<String> it = list.iterator();
			while(it.hasNext())
				actual += it.next() + "\r\n";
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testManualIteratorOnOneItemMyList: " + e.getMessage());
		}
		
	}
	
	@Test
	public void testIteratorOnFiveItemMyList() {
		try{
			MyList list = new MyList();
			list.addLast("one");
			list.addLast("two");
			list.addLast("three");
			list.addLast("four");
			list.addLast("five");
			
			String actual = "";
			String expected = "one\r\ntwo\r\nthree\r\nfour\r\nfive\r\n";
			
			for (String s: list)
				actual += s + "\r\n";
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testIteratorOnFiveItemMyList: " + e.getMessage());
		}
		
	}
	
	@Test
	public void testManualIteratorOnFiveItemMyList() {
		try{
			MyList list = new MyList();
			list.addLast("one");
			list.addLast("two");
			list.addLast("three");
			list.addLast("four");
			list.addLast("five");
			
			String actual = "";
			String expected = "one\r\ntwo\r\nthree\r\nfour\r\nfive\r\n";
			
			Iterator<String> it = list.iterator();
			while(it.hasNext())
				actual += it.next() + "\r\n";
			assertEquals(expected, actual);		
		}
		catch(Exception e){
			fail("Exception occurred in testManualIteratorOnFiveItemMyList: " + e.getMessage());
		}
		
	}

}
