package interfaces;
import java.util.ArrayList;
import java.util.Iterator;

/*
 * Simple example of Iterator usage
 * 
 * Includes automatic behavior via an enhanced for loop (foreach)
 * as well as doing the same thing 'manually' by
 * explicitly calling the hasNext() and next() methods
 * provided by the Iterator obtained from an ArrayList
 */
public class IteratorUsage {

	public static void main(String[] args) {
		ArrayList<String> words = new ArrayList<String>();
		words.add("This is");
		words.add("why");
		words.add("Iterators are");
		words.add("important!");
		
		// Ever wonder why or how the loop below�works?
		for (String str: words)
			System.out.print(str + " ");
		System.out.println();
		
		// This shows what's going on underneath :-)
		System.out.println("Same thing done 'manually'");
		for (Iterator<String> iterator = words.iterator(); iterator.hasNext(); ) {
			System.out.print(iterator.next() + " "); //next() retrieves next item and advances iterator
		}

	}

}
